package com.example.inventoryprojectcraigharrigan;

public class Item {
    //Project specific Item constructor
    private long itemId;
    private String username;
    private String itemTitle;
    private String itemQuantity;
    private String itemQuantityUnits;
    private boolean expanded;

    public Item(long id, String username, String title, String quantity) {
        this.itemId = id;
        this.username = username;
        this.itemTitle = title;
        this.itemQuantity = quantity;
        this.expanded = false;
    }

    public boolean isExpanded() {
        return expanded;
    }

    public void setExpanded(boolean expanded) {
        this.expanded = expanded;
    }

    public long getId() {
        return itemId;
    }
    public void setId(int id) {
        this.itemId = id;
    }

    public String getTitle() {
        return itemTitle;
    }
    public void setTitle(String title) {
        this.itemTitle = title;
    }

    public String getQuantity() {
        return itemQuantity;
    }
    public void setQuantity(String quantity) {
        this.itemQuantity = quantity;
    }

}
