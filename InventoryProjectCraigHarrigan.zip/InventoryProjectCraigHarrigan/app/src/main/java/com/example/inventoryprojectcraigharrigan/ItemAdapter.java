package com.example.inventoryprojectcraigharrigan;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemVH>{
    InventoryDB inventoryDB;

    private static final String TAG = "ItemAdapter";
    List<Item> itemList;

    public ItemAdapter(List<Item> itemList) {this.itemList = itemList;}

    @NonNull
    @Override
    public ItemVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.inventory_object, parent, false);
        return new ItemVH(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemVH holder, @SuppressLint("RecyclerView") int position) {
        Context context = holder.itemView.getContext();
        inventoryDB = new InventoryDB(context);
        Item item = itemList.get(position);
        holder.titleTextView.setText(item.getTitle());
        holder.quantityTextView.setText(item.getQuantity());

        boolean isExpanded = itemList.get(position).isExpanded();
        holder.itemCardActions.setVisibility(isExpanded ? View.VISIBLE : View.GONE);

        // Deletes item when Delete button is clicked
        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inventoryDB.deleteItem(item.getId());
                itemList.remove(position);
                notifyItemRemoved(position);
                notifyDataSetChanged();
            }
        });

        // Opens dialog on InventoryDashaboardActivity to update the selected item
        // Sends arguments to the onUpdateItemClick function
        holder.updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((InventoryDashboardActivity)context).onUpdateItemClick(v, position, item.getId(), item.getTitle(), item.getQuantity());
            }
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    class ItemVH extends RecyclerView.ViewHolder {
        private static final String TAG = "ItemVH";

        TextView titleTextView, quantityTextView, quantityUnitsTextView;
        ConstraintLayout cardHeader, itemCardActions;
        ImageButton arrowButton;
        MaterialCardView cardView;
        MaterialButton deleteButton, updateButton;

        public ItemVH(@NonNull final View itemView) {
            super(itemView);

            titleTextView = itemView.findViewById(R.id.textItemTitle);
            quantityTextView = itemView.findViewById(R.id.textItemAmount);
            deleteButton = itemView.findViewById(R.id.buttonDeleteItem);
            updateButton = itemView.findViewById(R.id.buttonUpdate);


            }

        }

    // Adds item to the list and notifies that item was inserted at the end
    public void addItem(Item item) {
        itemList.add(item);
        notifyItemInserted(itemList.size()-1);
    }

    // Updates selected item at specified index and notifies that it changed
    public void updateItem(int itemIndex, String newItemTitle, String newItemQuantity, String newItemUnits) {
        itemList.get(itemIndex).setTitle(newItemTitle);
        itemList.get(itemIndex).setQuantity(newItemQuantity);
        notifyItemChanged(itemIndex);
    }
}
