package com.example.inventoryprojectcraigharrigan;

import android.content.Intent;
import android.os.Bundle;
import android.se.omapi.Session;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

public class LoginActivity extends AppCompatActivity {
    TextInputEditText username, password;
    Button registerButton, loginButton;
    SessionManager sessionManager;
    InventoryDB inventoryDB;

    private TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }
        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            if (username.getText().toString().trim().isEmpty() || password.getText().toString().trim().isEmpty()) {
                loginButton.setEnabled(false);
            } else {
                loginButton.setEnabled(true);
            }
        }
        @Override
        public void afterTextChanged(Editable s) {
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = (TextInputEditText) findViewById(R.id.username);
        password = (TextInputEditText) findViewById(R.id.password);
        loginButton = (Button) findViewById(R.id.buttonLogin);
        registerButton = (Button) findViewById(R.id.buttonRegister);

        username.addTextChangedListener(textWatcher);
        password.addTextChangedListener(textWatcher);

        sessionManager = new SessionManager(getApplicationContext());
        inventoryDB = new InventoryDB(this);
    }

    public void onRegisterClick(View v){
        boolean checkUsername = inventoryDB.checkUsername(username.getText().toString());
        if (checkUsername == true) {
            Toast toast = Toast.makeText(getApplicationContext(), "Username already used", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        } else {
            boolean addUser = inventoryDB.addUser(username.getText().toString(), password.getText().toString());
                if (addUser) {
                    Toast toast = Toast.makeText(getApplicationContext(), "Registration Success", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                }
                sessionManager.setLogin(true);
                sessionManager.setUsername(username.getText().toString());
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
        }
    }

    public void onLoginClick(View v) {
        boolean checkUsername = inventoryDB.checkUsername(username.getText().toString());
        if (checkUsername == false) {
            Toast toast = Toast.makeText(getApplicationContext(), "No such user", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        } else {
            boolean checkPassword = inventoryDB.checkPassword(username.getText().toString(), password.getText().toString());
            if (checkPassword == false) {
                Toast toast = Toast.makeText(getApplicationContext(), "Incorrect Credentials", Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
            } else {
                sessionManager.setLogin(true);
                sessionManager.setUsername(username.getText().toString());
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        }
    }

}
