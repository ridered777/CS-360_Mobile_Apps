package com.example.inventoryprojectcraigharrigan;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

import com.google.android.material.textfield.TextInputEditText;

public class UpdateItemsDialog extends AppCompatDialogFragment {
    private TextInputEditText updateItemTitle;
    private TextInputEditText updateItemQuantity;
    private UpdateItemDialogListener listener;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        int itemIndex = getArguments().getInt("itemIndex");
        long id = getArguments().getLong("id");
        String oldTitle = getArguments().getString("title");
        String oldQuantity = getArguments().getString("quantity");

        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.fragment_add_item, null);

        builder.setView(view)
                .setTitle("Update Item")
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }})
                .setPositiveButton("Update", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String itemTitle = updateItemTitle.getText().toString();
                        String itemQuantity = updateItemQuantity.getText().toString();
                        if (itemTitle == "" || itemQuantity == "") {
                            Toast toast = Toast.makeText(getActivity(), "All fields are required", Toast.LENGTH_SHORT);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();
                        } else {
                            listener.updateItemFromDialog(id, itemIndex, itemTitle, itemQuantity);
                        }
                    }
                });

        updateItemTitle = view.findViewById(R.id.textAddItemName);
        updateItemQuantity = view.findViewById(R.id.textAddItemAmount);

        updateItemTitle.setText(oldTitle);
        updateItemQuantity.setText(oldQuantity);

        return builder.create();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            listener = (UpdateItemDialogListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString() + "must implement AddItemDialogListener");
        }
    }

    public interface UpdateItemDialogListener{
        void updateItemFromDialog(long id, int itemIndex, String updatedItemTitle, String updatedItemQuantity);
    }
}
